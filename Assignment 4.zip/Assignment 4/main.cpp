// Program: demo2.cpp
// Purpose: Demonstrate use of bmplip for handling
//          bmp colored and grayscale images
//          Program load a gray image and store in another file
// Author:  Mohammad El-Ramly
// Date:    30 March 2018
// Version: 1.0

#include <iostream>
#include <algorithm>
#include <fstream>
#include <cstring>
#include <cmath>
#include "bmplib.cpp"

using namespace std;
unsigned char image[SIZE][SIZE];
unsigned char image2[SIZE][SIZE];
unsigned char image1[SIZE][SIZE];
void saveImage();
void loadImage();
void loadImage_2();
void saveImage ();

// ahmed gommah function
void Filter_2();
void Filter_3();
void Filter_5();

void Filter_6();
void Filter_8();
void Filter_9();


int main()
{
    string x ;
    cout << "1- Black and White Image .\n2- Invert Filter\n3- ! Merge Images .\n4- Flip Image .\n5- Rotate Image .\n6- ! Darken and Lighten Image .";
    cout << "\n7- ! Detect Image Edges .\n8- ! Enlarge Image .\n9- ! Shrink Image .\n10-  Save the image to a file .\n11-To End .";
    while ( true)
    {
        cout << "\n\nEnter Your Choose Please :";
        cin >> x ;
        if ( x == "2")
        {
            loadImage();
            Filter_2();
            saveImage();
        }

        if ( x == "3"){
            loadImage();
            loadImage_2();
            Filter_3();
            saveImage();
        }

        if ( x == "5")
        {
            loadImage();
            Filter_5();
            saveImage();
        }

        else if (x == "6"){
            loadImage();
            Filter_6();
            saveImage();
        }
        else if (x == "8"){
            loadImage();
            Filter_8();
            saveImage();
        }
          else if (x == "9"){
            loadImage();
            Filter_9();
            saveImage();
          }
        else if (x == "10"){
            saveImage();
        }
        else if ( x == "11")
            break;
        else
            continue;
    }

  return 0;
}

//_________________________________________
void loadImage () {
   char imageFileName[100];

   // Get gray scale image file name
   cout << "Enter the source image file name: ";
   cin >> imageFileName;

   // Add to it .bmp extension and load image
   strcat (imageFileName, ".bmp");
   readGSBMP(imageFileName, image);
   /////////////////////////////////////
}


//_________________________________________
void loadImage_2 () {
   char imageFileName2[100];

   // Get gray scale image file name
   cout << "Enter the source image file name: ";
   cin >> imageFileName2;

   // Add to it .bmp extension and load image
   strcat (imageFileName2, ".bmp");
   readGSBMP(imageFileName2 , image2);
   /////////////////////////////////////
}

//_________________________________________
void saveImage () {
   char imageFileName[100];

   // Get gray scale image target file name
   cout << "Enter the target image file name: ";
   cin >> imageFileName;

   // Add to it .bmp extension and load image
   strcat (imageFileName, ".bmp");
   writeGSBMP(imageFileName, image);
}
void Filter_2()
{

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
           image [i][j]=255-image [i][j];
        }
    }
}







void Filter_3()
{

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            image[i][j]=(image[i][j] + image2[i][j])/2;
        }
    }
}
void Filter_5()
{
    string x;
    char temp[SIZE][SIZE];

    cout <<"1-enter (1)for rotate 90\n2-enter (2) for rotate 180\n3-enter (3) for rotate 270\n";
    cin>>x;


    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            if (x=="1"){
            temp[j][SIZE-i-1]=image[i][j];
            }
            if (x=="2"){
            temp[SIZE-j-1][SIZE-i-1]=image[i][j];
            }
            if (x=="3"){
            temp[SIZE-j-1][i]=image[i][j];
            }
        }
    }

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            image[i][j]=temp[i][j];
        }
    }

}


//_________________________________________


void Filter_6()
{
    string x ;
    cout << "1- if you want dark image .\n2- if you want light image .";
    cin >> x ;
    if ( x == "1")
    {

     if (x == "1")
    {
        for (int i = 0; i < SIZE; i++)
        {
            for (int j = 0; j< SIZE; j++)
            {
                image[i][j]/=2;
            }
        }
    }
    else if ( x == "2")
    {
        for ( int i = 0 ; i < SIZE ; i++)
        {
            for ( int j = 0 ; j <SIZE; j++)
            {
                image[i][j] +=55;
            }
        }
    }
}

}
void Filter_8()
{
    int a,b;
    char temp[SIZE][SIZE];
    string x;
    cout <<"Do you want any Enlarge Image?\n1- for first quartile\n2-second quartile\n3-third quartile\n4-fourth quartile\n";
    cin>>x;
    if (x=="1")
        a=0,b=0;
    else if (x=="2")
        a=0,b=128;
    else if (x=="3")
        a=128,b=0;
    else if (x=="4")
        a=128,b=128;

    for (int i = 0; i < SIZE; i+=2 , a++) {
        for (int j = 0; j < SIZE; j+=2 ,b++) {
                temp[i][j]=image[a][b];
                temp[i+1][j+1]=image[a][b];
                temp[i][j+1]=image[a][b];
                temp[i+1][j]=image[a][b];
        }

        if (x=="1")
            b=0;
        else if (x=="2")
            b=128;
        else if (x=="3")
            b=0;
        else if (x=="4")
            b=128;

    }
    /* if (x=="2"){
        for (int i = 0; i < (SIZE*2)/4; i++)
        {
            for (int j = 0; j< (SIZE*2)/4; j++)
            {

                temp[i][j]=image [i*4][j*4];
            }
        }
    }
     if (x=="3"){
        for (int i = 0; i < SIZE/4; i++)
        {
            for (int j = 0; j< SIZE/4; j++)
            {

                temp[i][j]=image [i*4][j*4];
            }
        }
    }
     if (x=="4"){
        for (int i = 0; i < SIZE/4; i++)
        {
            for (int j = 0; j< SIZE/4; j++)
            {

                temp[i][j]=image [i*4][j*4];
            }
        }
    }*/

    for (int i = 0; i < SIZE; i++)
    {
        for (int j = 0; j< SIZE; j++)
        {
            image[i][j]=temp[i][j];
        }
    }
}
void Filter_9()
{
string x;
cout<<"for shrinking 1/2 cin : 1"<<endl <<"for shrinking 1/3 cin : 2"<<endl<<"for shrinking 1/4 cin : 3"<<endl;
cin>>x;

    for (int i=0; i<SIZE;i++){

            for (int j=0; j<SIZE;j++){
                    if(x=="1")
                    {
                        image1[i/2] [j/2]=image1[i] [j];
                    }
                    else if (x=="2")
                    {
                        image1[i/3] [j/3]=image1[i] [j];
                    }
                    else if (x=="2")
                    {
                        image1[i/4] [j/4]=image1[i] [j];
                    }
            }
    }

}


